﻿import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'redrelay-lifeline-jwt-secret-2026';

export function signToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '24h' });
}

export function verifyToken(token) {
  return jwt.verify(token, JWT_SECRET);
}

// Attaches req.user if a valid Bearer token is provided
export function optionalAuth(req, _res, next) {
  const header = req.headers.authorization || '';
  if (header.startsWith('Bearer ')) {
    try {
      req.user = verifyToken(header.slice(7));
    } catch {
      req.user = null;
    }
  }
  next();
}

// Strictly enforces a valid JWT Bearer token
export function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) {
    return res.status(401).json({
      error: 'Authentication required. Provide a valid Bearer token.',
      code: 'AUTH_MISSING_TOKEN',
      status: 401,
    });
  }
  try {
    req.user = verifyToken(header.slice(7));
    next();
  } catch {
    return res.status(401).json({
      error: 'Invalid or expired authentication token.',
      code: 'AUTH_INVALID_TOKEN',
      status: 401,
    });
  }
}
