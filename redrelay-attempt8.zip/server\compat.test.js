import assert from 'node:assert/strict';
import { GROUPS, canDonate, donorsFor, recipientsOf } from './compat.js';

for (const g of GROUPS) {
  assert.ok(canDonate('O-', g), `O- should give to ${g}`);
  assert.ok(canDonate(g, 'AB+'), `${g} should give to AB+`);
}
assert.deepEqual(recipientsOf('AB+'), ['AB+']);
assert.deepEqual(recipientsOf('A-').sort(), ['A+', 'A-', 'AB+', 'AB-']);
assert.deepEqual(donorsFor('B+').sort(), ['B+', 'B-', 'O+', 'O-']);
for (const r of GROUPS.filter((g) => g.endsWith('-')))
  for (const d of donorsFor(r)) assert.ok(d.endsWith('-'), `${d} -> ${r} breaks Rh rule`);
assert.ok(!canDonate('A+', 'B+') && !canDonate('B+', 'A+'));
console.log('compat matrix: all checks passed');
