import { Link } from 'react-router-dom';
import { Clock, MapPin } from 'lucide-react';
import { timeLeft } from '../api.js';

const LABEL = { open: 'Broadcasting', responded: 'Donors responded', fulfilled: 'Units covered', closed: 'Closed' };

export default function RequestCard({ r }) {
  const live = r.status !== 'closed';
  const pct = Math.min(100, Math.round((r.committed / r.units) * 100));
  return (
    <Link to={`/request/${r.id}`} className={`flex gap-4 rounded-xl border bg-white p-4 ${live ? 'border-blood/40' : 'border-ink/10 opacity-70'}`}>
      <div className={`flex h-16 w-16 shrink-0 items-center justify-center rounded-xl text-2xl font-extrabold ${live ? 'bg-blood text-white' : 'bg-ink/10'}`}>
        {r.bloodGroup}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          {live && <span className="sos-dot shrink-0" aria-hidden />}
          <h3 className="truncate font-bold">{r.hospital}</h3>
        </div>
        <p className="mt-0.5 flex flex-wrap gap-x-3 text-sm text-ink/70">
          <span className="flex items-center gap-1"><MapPin size={14} />{r.locality}</span>
          {live && <span className="flex items-center gap-1"><Clock size={14} />{timeLeft(r.deadlineAt)}</span>}
          <span>Patient {r.patient}</span>
        </p>
        <div className="mt-3 flex items-center gap-3">
          <div className="h-2 flex-1 overflow-hidden rounded-full bg-ink/10">
            <div className="h-full rounded-full bg-ok transition-all duration-700" style={{ width: `${pct}%` }} />
          </div>
          <span className="whitespace-nowrap text-sm font-semibold">{r.committed}/{r.units} units committed</span>
        </div>
        <p className="mt-1 text-xs text-ink/60">{LABEL[r.status]}{r.closedReason === 'expired' ? ' (expired after 24h)' : ''}</p>
      </div>
    </Link>
  );
}
