import { Check } from 'lucide-react';

const STEPS = [
  ['open', 'Open / Broadcasted'],
  ['responded', 'Donors Responded'],
  ['fulfilled', 'Fulfilled / In Transit'],
  ['closed', 'Closed'],
];

export default function Stepper({ status }) {
  const at = STEPS.findIndex(([k]) => k === status);
  return (
    <ol className="flex w-full items-start" aria-label="Request progress">
      {STEPS.map(([key, label], i) => {
        const done = i < at || status === 'closed';
        const current = i === at && status !== 'closed';
        return (
          <li key={key} className="relative flex flex-1 flex-col items-center text-center" aria-current={current ? 'step' : undefined}>
            {i > 0 && <span className={`absolute right-1/2 top-4 h-1 w-full ${i <= at ? 'bg-ok' : 'bg-ink/15'}`} />}
            <span className={`relative z-10 flex h-8 w-8 items-center justify-center rounded-full border-2 text-sm font-bold
              ${done ? 'border-ok bg-ok text-white' : current ? 'border-blood bg-blood text-white' : 'border-ink/25 bg-white text-ink/50'}`}>
              {done ? <Check size={16} /> : i + 1}
            </span>
            <span className={`mt-2 px-1 text-xs sm:text-sm ${current ? 'font-bold text-blood' : done ? 'font-semibold' : 'text-ink/60'}`}>{label}</span>
          </li>
        );
      })}
    </ol>
  );
}
