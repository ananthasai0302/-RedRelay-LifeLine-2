﻿import 'dotenv/config';
import crypto from 'node:crypto';
import jwt from 'jsonwebtoken';
import { AppError } from '../utils/AppError.js';

const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(32).toString('hex');
export const signToken = (payload) => jwt.sign(payload, JWT_SECRET, { expiresIn: '24h' });
export const verifyToken = (token) => jwt.verify(token, JWT_SECRET);

export function optionalAuth(req, _res, next) {
  const header = req.headers.authorization || '';
  if (header.startsWith('Bearer ')) {
    try { req.user = verifyToken(header.slice(7)); } catch { req.user = null; }
  }
  next();
}

export function requireAuth(req, _res, next) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return next(new AppError(401, 'Authentication required', 'AUTH_MISSING_TOKEN'));
  try { req.user = verifyToken(header.slice(7)); next(); }
  catch { next(new AppError(401, 'Invalid or expired token', 'AUTH_INVALID_TOKEN')); }
}

export function requireRole(...allowedRoles) {
  return (req, _res, next) => {
    if (!req.user) return next(new AppError(401, 'Authentication required', 'AUTH_REQUIRED'));
    if (!allowedRoles.includes(req.user.role)) return next(new AppError(403, `Required role: ${allowedRoles.join(' or ')}`, 'RBAC_FORBIDDEN'));
    next();
  };
}
