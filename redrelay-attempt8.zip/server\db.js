﻿import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { LOCALITIES } from './data/localities.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const dbPath = process.env.DB_PATH || path.join(here, 'redrelay.db');
export const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
export { LOCALITIES };

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'member',
  donor_id INTEGER REFERENCES donors(id),
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS donors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  blood_group TEXT NOT NULL,
  locality TEXT NOT NULL,
  phone TEXT NOT NULL,
  available INTEGER NOT NULL DEFAULT 1,
  last_donation INTEGER
);
CREATE TABLE IF NOT EXISTS requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient TEXT NOT NULL,
  hospital TEXT NOT NULL,
  locality TEXT NOT NULL,
  blood_group TEXT NOT NULL,
  units INTEGER NOT NULL,
  deadline_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  doctor_contact TEXT NOT NULL,
  token TEXT NOT NULL,
  created_by INTEGER REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'open',
  closed_reason TEXT,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS responses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  request_id INTEGER NOT NULL REFERENCES requests(id),
  donor_id INTEGER NOT NULL REFERENCES donors(id),
  units INTEGER NOT NULL DEFAULT 1,
  state TEXT NOT NULL DEFAULT 'committed',
  created_at INTEGER NOT NULL,
  UNIQUE (request_id, donor_id)
);
CREATE INDEX IF NOT EXISTS idx_requests_status_deadline ON requests(status, deadline_at);
CREATE INDEX IF NOT EXISTS idx_donors_blood_locality ON donors(blood_group, locality);
`);

function seed() {
  if (db.prepare('SELECT COUNT(*) n FROM donors').get().n > 0) return;
  const DAY = 864e5, HOUR = 36e5, now = Date.now();
  const names = [
    'Ravi Kumar', 'Sneha Reddy', 'Imran Shaikh', 'Lakshmi Prasad', 'Arjun Naidu',
    'Fatima Begum', 'Kiran Rao', 'Divya Teja', 'Suresh Goud', 'Anitha Varma',
    'Mohan Babu', 'Priya Sharma', 'Venkat Rao', 'Zoya Khan', 'Harish Yadav',
    'Meena Kumari', 'Sai Charan', 'Nikhil Joshi', 'Pooja Menon', 'Rahul Verma',
    'Swathi Chary', 'Farhan Ali', 'Deepa Nair', 'Ganesh Pillai', 'Rekha Devi',
    'Tarun Mehta', 'Bhavana Reddy', 'Asif Hussain', 'Nandini Rao', 'Vamsi Krishna',
  ];
  const groups = ['O+', 'B+', 'A+', 'B+', 'O-', 'AB+', 'B-', 'A-', 'O+', 'AB-'];
  const places = Object.keys(LOCALITIES);
  const ins = db.prepare('INSERT INTO donors (name, blood_group, locality, phone, available, last_donation) VALUES (?,?,?,?,?,?)');
  names.forEach((n, i) => {
    const recentlyDonated = i === 4 || i === 13 ? now - 20 * DAY : null;
    const busy = i === 9 ? 0 : 1;
    ins.run(n, groups[i % groups.length], places[(i * 3) % places.length], `9848${String(100000 + i * 3719).slice(-6)}`, busy, recentlyDonated);
  });

  const demoHash = bcrypt.hashSync('RedRelay@123', 10);
  db.prepare('INSERT INTO users (name, email, password_hash, role, donor_id, created_at) VALUES (?,?,?,?,?,?)')
    .run('Ravi Kumar', 'ravi@redrelay.org', demoHash, 'donor', 1, now);

  const mk = db.prepare(`INSERT INTO requests (patient, hospital, locality, blood_group, units, deadline_at, expires_at, doctor_contact, token, status, created_at)
                         VALUES (?,?,?,?,?,?,?,?,?,?,?)`);
  const reqs = [
    ['Ramesh Gupta', 'Apollo Hospital, Jubilee Hills', 'Banjara Hills', 'B+', 2, 4, 'Emergency surgery'],
    ['Sunita Devi', 'Care Hospitals, Kukatpally', 'Kukatpally', 'O-', 3, 2, 'Childbirth complication'],
    ['Abdul Karim', 'Yashoda Hospital, Secunderabad', 'Secunderabad', 'A+', 1, 6, 'Road accident'],
    ['Meghana Rao', 'Continental Hospitals, Gachibowli', 'Gachibowli', 'AB+', 2, 8, 'Trauma surgery'],
    ['Joseph Thomas', 'Medicover, Madhapur', 'Madhapur', 'A-', 2, 3, 'Internal bleeding'],
  ];
  reqs.forEach(([p, h, l, g, u, hrs], i) => {
    const created = now - (i + 1) * 12 * 60e3;
    mk.run(p, h, l, g, u, created + hrs * HOUR, created + 24 * HOUR, '9000000000', `seed-token-${i + 1}`, 'open', created);
  });
}
seed();
