﻿// Decoupled Hyderabad locality coordinates (lat, lng) and Haversine distance helpers.
export const LOCALITIES = {
  'Banjara Hills': [17.4126, 78.4482],
  'Ameerpet': [17.4375, 78.4483],
  'Madhapur': [17.4483, 78.3915],
  'Gachibowli': [17.4401, 78.3489],
  'Kukatpally': [17.4948, 78.3996],
  'Secunderabad': [17.4399, 78.4983],
  'Uppal': [17.4018, 78.56],
  'Dilsukhnagar': [17.3688, 78.5247],
  'LB Nagar': [17.3457, 78.5522],
  'Medchal': [17.6297, 78.4814],
};

export function calculateDistanceKm(locA, locB) {
  if (!LOCALITIES[locA] || !LOCALITIES[locB]) return Infinity;
  const [la1, lo1] = LOCALITIES[locA];
  const [la2, lo2] = LOCALITIES[locB];
  const rad = (deg) => (deg * Math.PI) / 180;
  const h =
    Math.sin(rad(la2 - la1) / 2) ** 2 +
    Math.cos(rad(la1)) * Math.cos(rad(la2)) * Math.sin(rad(lo2 - lo1) / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.sqrt(h));
}

// Urban traffic estimation: ~22 km/h average plus 4 min dispatch overhead
export const estimateEtaMinutes = (distanceKm) => Math.round((distanceKm / 22) * 60) + 4;
