﻿export const logger = {
  info(event, meta = {}) {
    if (process.env.NODE_ENV !== 'test') console.log(JSON.stringify({ level: 'info', timestamp: new Date().toISOString(), event, ...meta }));
  },
  warn(event, meta = {}) {
    if (process.env.NODE_ENV !== 'test') console.warn(JSON.stringify({ level: 'warn', timestamp: new Date().toISOString(), event, ...meta }));
  },
  error(event, meta = {}) {
    console.error(JSON.stringify({ level: 'error', timestamp: new Date().toISOString(), event, ...meta }));
  },
};
