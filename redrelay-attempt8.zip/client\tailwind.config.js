export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#16222E',
        paper: '#F2F4F6',
        blood: { DEFAULT: '#B8142C', dark: '#8E0F22', tint: '#FBE9EC' },
        ok: { DEFAULT: '#0F766E', tint: '#DDF3F0' },
        warn: { DEFAULT: '#A8530A', tint: '#FCEBD6' },
      },
      fontFamily: { sans: ['"Bricolage Grotesque"', 'system-ui', 'sans-serif'] },
    },
  },
  plugins: [],
};
