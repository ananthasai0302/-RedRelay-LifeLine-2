﻿import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

export default function LocalityMap({ center, hospital, radiusKm, donors = [] }) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);

  useEffect(() => {
    if (!containerRef.current || !center) return;
    if (!mapRef.current) {
      mapRef.current = L.map(containerRef.current).setView(center, 12);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
      }).addTo(mapRef.current);
    }
    const map = mapRef.current;
    map.setView(center, 12);
    map.eachLayer((layer) => { if (!(layer instanceof L.TileLayer)) map.removeLayer(layer); });

    L.circleMarker(center, { radius: 9, color: '#b91c1c', fillColor: '#dc2626', fillOpacity: 0.9 })
      .addTo(map).bindPopup(`<strong>${hospital}</strong><br/>Target Radius: ${radiusKm} km`);

    L.circle(center, { radius: radiusKm * 1000, color: '#dc2626', fillColor: '#fca5a5', fillOpacity: 0.15, weight: 1.5 }).addTo(map);

    donors.forEach((d) => {
      if (d.coords) {
        L.circleMarker(d.coords, { radius: 6, color: '#0f766e', fillColor: '#14b8a6', fillOpacity: 0.85 })
          .addTo(map).bindPopup(`<strong>${d.initials}</strong> (${d.bloodGroup})<br/>${d.locality} • ${d.distanceKm} km (~${d.etaMin} min)`);
      }
    });
  }, [center, hospital, radiusKm, donors]);

  return <div ref={containerRef} className="h-64 w-full rounded-xl border border-ink/15 z-0" />;
}
