﻿import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { db } from './db.js';
import { LOCALITIES, calculateDistanceKm, estimateEtaMinutes } from './data/localities.js';
import { GROUPS, canDonate, donorsFor } from './compat.js';
import { signToken, optionalAuth, requireAuth, requireRole } from './middleware/auth.js';
import { AppError } from './utils/AppError.js';
import { logger } from './utils/logger.js';
import { dispatchEmergencySms } from './services/smsService.js';

const HOUR = 36e5, DAY = 24 * HOUR, COOLDOWN = 90 * DAY;
export const app = express();

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(express.json({ limit: '50kb' }));

app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    logger.info('http.request', { method: req.method, path: req.originalUrl, status: res.statusCode, durationMs: Date.now() - start, userId: req.user?.id || null });
  });
  next();
});

const initials = (name) => name.split(/\s+/).filter(Boolean).map((p) => p.toUpperCase()).join('.') + '.';
const isReady = (d) => d.available === 1 && (!d.last_donation || Date.now() - d.last_donation >= COOLDOWN);
const unlockAt = (d) => (d.last_donation && Date.now() - d.last_donation < COOLDOWN ? d.last_donation + COOLDOWN : null);
const committedFor = (id) => db.prepare('SELECT COALESCE(SUM(units),0) n FROM responses WHERE request_id = ?').get(id).n;

function haversineCoords([la1, lo1], [la2, lo2]) {
  const rad = (deg) => (deg * Math.PI) / 180;
  const h = Math.sin(rad(la2 - la1) / 2) ** 2 + Math.cos(rad(la1)) * Math.cos(rad(la2)) * Math.sin(rad(lo2 - lo1) / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.sqrt(h));
}

function refresh(id) {
  let r = db.prepare('SELECT * FROM requests WHERE id = ?').get(id);
  if (!r || r.status === 'closed') return r;
  if (Date.now() > r.expires_at) {
    db.prepare("UPDATE requests SET status='closed', closed_reason='expired' WHERE id=?").run(id);
    return db.prepare('SELECT * FROM requests WHERE id = ?').get(id);
  }
  const c = committedFor(id);
  const status = c >= r.units ? 'fulfilled' : c > 0 ? 'responded' : 'open';
  if (status !== r.status) db.prepare('UPDATE requests SET status=? WHERE id=?').run(status, id);
  return { ...r, status };
}

const publicRequest = (r) => ({
  id: r.id, patient: initials(r.patient), hospital: r.hospital, locality: r.locality,
  coords: LOCALITIES[r.locality] || [17.4126, 78.4482], bloodGroup: r.blood_group,
  units: r.units, committed: committedFor(r.id), status: r.status, closedReason: r.closed_reason,
  deadlineAt: r.deadline_at, expiresAt: r.expires_at, createdAt: r.created_at, compatibleGroups: donorsFor(r.blood_group),
});

function eligibleDonors(r, radius, gpsCoords = null) {
  const groups = donorsFor(r.blood_group);
  const targetCoords = gpsCoords || LOCALITIES[r.locality];
  return db.prepare(`SELECT * FROM donors WHERE blood_group IN (${groups.map(() => '?').join(',')})`).all(...groups)
    .filter(isReady)
    .map((d) => ({ d, dist: targetCoords && LOCALITIES[d.locality] ? haversineCoords(LOCALITIES[d.locality], targetCoords) : calculateDistanceKm(d.locality, r.locality) }))
    .filter((x) => x.dist <= radius)
    .sort((a, b) => a.dist - b.dist)
    .map(({ d, dist }) => ({
      id: d.id, initials: initials(d.name), bloodGroup: d.blood_group, locality: d.locality,
      coords: LOCALITIES[d.locality], distanceKm: Math.round(dist * 10) / 10, etaMin: estimateEtaMinutes(dist), rawPhone: d.phone,
    }));
}

app.post('/api/auth/register', (req, res, next) => {
  try {
    const { name, email, password, role } = req.body || {};
    if (!name?.trim()) throw new AppError(400, 'Full name is required', 'VALIDATION_NAME');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || ''))) throw new AppError(400, 'Enter a valid email address', 'VALIDATION_EMAIL');
    if (typeof password !== 'string' || password.length < 6) throw new AppError(400, 'Password must be at least 6 characters', 'VALIDATION_PASSWORD');
    const cleanEmail = email.trim().toLowerCase();
    if (db.prepare('SELECT id FROM users WHERE email = ?').get(cleanEmail)) throw new AppError(409, 'Email already exists', 'AUTH_EMAIL_EXISTS');
    const assignedRole = ['donor', 'coordinator', 'member'].includes(role) ? role : 'member';
    const info = db.prepare('INSERT INTO users (name, email, password_hash, role, created_at) VALUES (?,?,?,?,?)').run(name.trim(), cleanEmail, bcrypt.hashSync(password, 10), assignedRole, Date.now());
    const user = { id: Number(info.lastInsertRowid), name: name.trim(), email: cleanEmail, role: assignedRole };
    logger.info('auth.register', { userId: user.id, role: assignedRole });
    res.status(201).json({ token: signToken(user), user });
  } catch (err) { next(err); }
});

app.post('/api/auth/login', (req, res, next) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) throw new AppError(400, 'Email and password are required', 'AUTH_MISSING_CREDENTIALS');
    const row = db.prepare('SELECT * FROM users WHERE email = ?').get(String(email).trim().toLowerCase());
    if (!row || !bcrypt.compareSync(String(password), row.password_hash)) throw new AppError(401, 'Invalid email or password', 'AUTH_INVALID_CREDENTIALS');
    const user = { id: row.id, name: row.name, email: row.email, role: row.role, donorId: row.donor_id };
    logger.info('auth.login', { userId: user.id, role: user.role });
    res.json({ token: signToken(user), user });
  } catch (err) { next(err); }
});

app.get('/api/auth/me', requireAuth, (req, res) => res.json({ user: req.user }));
app.get('/api/meta', (_req, res) => res.json({ localities: Object.keys(LOCALITIES), localityCoords: LOCALITIES, groups: GROUPS }));

app.get('/api/requests', (req, res) => {
  const page = Math.max(Number(req.query.page) || 1, 1);
  const limit = Math.min(Math.max(Number(req.query.limit) || 20, 1), 100);
  const offset = (page - 1) * limit;
  const all = db.prepare('SELECT id FROM requests ORDER BY created_at DESC LIMIT 200').all().map((x) => publicRequest(refresh(x.id)));
  const combined = [...all.filter((r) => r.status !== 'closed').sort((a, b) => a.deadlineAt - b.deadlineAt), ...all.filter((r) => r.status === 'closed')];
  const total = combined.length, totalPages = Math.max(Math.ceil(total / limit), 1), items = combined.slice(offset, offset + limit);
  res.set('X-Total-Count', String(total)); res.set('X-Page', String(page)); res.set('X-Total-Pages', String(totalPages));
  if (req.query.paginated === '1') return res.json({ items, total, page, limit, totalPages });
  res.json(items);
});
