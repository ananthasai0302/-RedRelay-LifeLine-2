﻿import twilio from 'twilio';
import { logger } from '../utils/logger.js';

export async function dispatchEmergencySms(recipients, requestInfo) {
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const authToken = process.env.TWILIO_AUTH_TOKEN;
  const fromNumber = process.env.TWILIO_PHONE_NUMBER;
  const client = sid && authToken && fromNumber ? twilio(sid, authToken) : null;

  const results = [];
  for (const donor of recipients) {
    const body = `RedRelay SOS: ${requestInfo.units} unit(s) of ${requestInfo.blood_group} needed at ${requestInfo.hospital} (${donor.distanceKm} km away).`;
    if (client && donor.rawPhone) {
      const msg = await client.messages.create({ body, from: fromNumber, to: `+91${donor.rawPhone}` });
      logger.info('sms.dispatched', { provider: 'twilio', sid: msg.sid, to: donor.initials });
      results.push({ to: `${donor.initials} (${donor.locality})`, text: body, provider: 'twilio', sid: msg.sid });
    } else {
      logger.info('sms.dispatched', { provider: 'sandbox', to: donor.initials, distanceKm: donor.distanceKm });
      results.push({ to: `${donor.initials} (${donor.locality})`, text: body, provider: 'sandbox' });
    }
  }
  return results;
}
